gcc -Wall  main.c ../common/data.c stack.c -o mainStack
