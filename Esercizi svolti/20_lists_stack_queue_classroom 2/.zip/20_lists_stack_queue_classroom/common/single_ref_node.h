#ifndef NODE_H
    #define NODE_H
    #include "data.h"//contiene la definiz. del dato
    struct nodo{
	struct dato d;
	struct nodo * next; 
    }; 
#endif 
