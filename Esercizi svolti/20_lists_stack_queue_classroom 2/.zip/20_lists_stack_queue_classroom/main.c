#include "./lists/single_linked_lists/single_linked_list.h"
#include "./common/data.h"

#include <stdlib.h>

int main(){

    struct nodo *head = NULL; //lista vuota 

    struct dato d = {5};
    
    insert(&d, &head); 
    // ... 

    delete(...);  


}
