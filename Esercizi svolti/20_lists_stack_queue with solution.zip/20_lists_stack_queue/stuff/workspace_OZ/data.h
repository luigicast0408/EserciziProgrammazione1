#ifndef DATA_H
    #define DATA_H  
    struct dato{
	int value; 
    }; 
    
    int confrontaDati(struct dato *d1, struct dato *d2);
    void printDato(struct dato *d);
#endif 
