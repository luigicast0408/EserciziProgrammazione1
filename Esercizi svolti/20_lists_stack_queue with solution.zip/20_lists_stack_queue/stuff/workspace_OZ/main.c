#include "list.h"
#include "node.h"
#include "data.h"

#include <stdio.h>

int main(){

    // lista inizialmente vuota
    struct node * head = NULL; 

}
