#include <stdio.h>

#define M1 10 
#define M2 23.456


int main(){

  const float una_costante = 56.789; 

  printf("\n M1= %d", M1); 
  printf("\n M2= %f", M2);

  // si invochi il programma gcc con il flag -E..
  //

  // $ gcc -E sorgente.c

}


