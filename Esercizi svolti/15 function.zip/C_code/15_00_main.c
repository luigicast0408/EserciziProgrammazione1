 /* Notare le virgolette al posto delle parentesi 
* angolari 
*/ 

#include <stdio.h>
#include <string.h>

#include "15_00.h" 

int main(){

  stampa("messaggio della funzione main().."); 

}
