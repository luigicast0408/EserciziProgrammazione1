#include <stdio.h>

void stampa(char *s){

  printf("stampa(): %s", s);

}
