void stampa(char *s); 
