#ifndef ARRAY_PTR
  #define ARRAY_PTR

#include <stdio.h>

void arrSelectSort(int *[], int);
void showArray(int [], int);
void showArrPtr(int *[], int);

#endif
