gcc -Wall 15_00_main.c 15_00_func.c -o A15_00 
gcc -Wall 15_01.c -o 15_01 
gcc -Wall 15_02.c -o 15_02 
gcc -Wall 15_mem.c -o 15_mem 
gcc -Wall PTR_01.c -o PTR_01 
gcc -Wall PTR_02.c -o PTR_02 
gcc -Wall PTR_03.c -o PTR_03 
gcc -Wall PTR_04.c -o PTR_04 
gcc -Wall PTR_05.c -o PTR_05 
gcc -Wall PTR_06.c -o PTR_06 
gcc -Wall PTR_07.c -o PTR_07 
gcc -Wall PTR_08.c -o PTR_08 
gcc -Wall PTR_09.c -o PTR_09 
gcc -Wall PTR_10.c -o PTR_10 array_ptr.c 
gcc -Wall PTR_11.c -o PTR_11
