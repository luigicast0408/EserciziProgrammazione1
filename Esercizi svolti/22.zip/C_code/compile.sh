#!/bin/bash
gcc 22_01_fopen.c -o 22_01_fopen 
gcc 22_02_fprintf.c -o 22_02_fprintf
gcc 22_02_fputs.c -o 22_02_fputs 
gcc 22_03_fgets.c -o 22_03_fgets
gcc 22_03_fscanf.c -o 22_03_fscanf
gcc 22_04_fwrite.c -o 22_04_fwrite
gcc 22_05_fread.c -o 22_05_fread 
gcc 22_06_fread_fwrite.c -o 22_06_fread_fwrite
