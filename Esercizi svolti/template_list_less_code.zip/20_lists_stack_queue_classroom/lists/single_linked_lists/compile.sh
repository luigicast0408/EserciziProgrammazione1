gcc -Wall main.c single_linked_list.c ../../common/data.c -o main_list
