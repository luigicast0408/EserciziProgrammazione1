gcc -Wall main.c ../../common/data.c queue.c -o mainQueue 
