gcc -Wall 19_01.c -o 19_01
gcc -Wall 19_02.c -o 19_02
gcc -Wall 19_03.c -o 19_03
gcc -Wall 19_04.c -o 19_04
gcc -Wall 19_05.c -o 19_05
gcc -Wall 19_06.c -o 19_06
