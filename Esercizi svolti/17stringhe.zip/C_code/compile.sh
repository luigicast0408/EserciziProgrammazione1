gcc -Wall -std=c18 17_01.c -o 17_01
gcc -Wall -std=c18 17_02.c -o 17_02
gcc -Wall -std=c18 17_03.c -o 17_03
gcc -Wall -std=c18 17_04.c -o 17_04
