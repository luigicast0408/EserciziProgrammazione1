
#ifndef FLUSH
#define FLUSH 

void flush_stdin(); 

#endif 
