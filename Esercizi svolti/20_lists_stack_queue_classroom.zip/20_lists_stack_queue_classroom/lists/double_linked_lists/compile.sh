gcc main.c double_linked_list.c ../../common/data.c -o double_linked_list
