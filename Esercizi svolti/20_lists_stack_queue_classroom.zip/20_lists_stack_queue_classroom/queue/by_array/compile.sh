gcc -Wall main.c circularQueue.c -o mainCircularQueue
